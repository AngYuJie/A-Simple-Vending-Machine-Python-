#Author: Ang yu jie
#Admin No: 214144U

# import a function for copy
import copy

# A dictionary call items to store all the drink id's, description, price and quantity.
items = {'IM': {'description': 'Iced Milo', 'price': 1.5, 'quantity': 20},
         'HM': {'description': 'Hot Milo', 'price': 1.2, 'quantity': 20},
         'IC': {'description': 'Iced Coffee', 'price': 1.5, 'quantity': 2},
         'HC': {'description': 'Hot Coffee', 'price': 1.2, 'quantity': 0},
         '1P': {'description': '100 Plus', 'price': 1.1, 'quantity': 50},
         'CC': {'description': 'Coca Cola', 'price': 1.3, 'quantity': 50},
         'JT': {'description': 'Jasmine Tea', 'price': 1.2, 'quantity': 50},
         }

#To print an error message with reason
def error_Prompt(errorMsg,errorCode):
    if errorCode == 1:
        print("Invalid Input!",errorMsg)
    else:
        print(errorMsg)


#To print the following greeting
def messages():
    print("Welcome to ABC Vending Machine\nSelect from the following choices to continue: ")

# to print get the first user input to check if they are vendor or not
def greetings():

    # A while loop that will be executed till break.
    while True:
        # user_Input to ask users if they are vendor or not
        user_Input = input("Are you a vendor (Y/N): ")

        # if condition to check if user_input, converted to upper case equals to "Y"
        if user_Input.upper() == "Y":

            #retrun the userInput
            return user_Input

            #break the loop
            break

        # elif condition to check if user_input, converted to upper case equals to "N"
        elif user_Input.upper() == "N":

            #retrun the userInput
            return user_Input

            #break the loop
            break

        # else condition if user_input, did not meet any of the previous condition
        else:

            # execute this function and send 'Enter "Y" for yes and "N" for no' to the function
            error_Prompt('Enter "Y" for yes and "N" for no',1)



def vendorMsg():
    # print statement to print the options.
    print("1. Add Drink Type\n2. Replenish Drink\n0. Exit")

#vendor section
def vendor():
    # constant loop to validate if the option is 1,2,0

    # A while loop that will be executed till break
    while True:

        # user_Input to ask users if they want to "1. Add Drink Type\n2. Replenish Drink\n0. Exit"
        User_Input = input('Enter Choice: ')

        # A if condition to check if User_Input equals to "1"
        if User_Input == '1':

            #retrun the User_Input
            return User_Input

            #break the loop
            break

        # elif condition to check if User_Input equals "2"
        elif User_Input == '2':

            #retrun the User_Input
            return User_Input

            #break the loop
            break

        # elif condition to check if User_Input equals "0"
        elif User_Input == '0':

           #retrun the User_Input
            return User_Input

           #break the loop
            break

        # else condition if User_Input, did not meet any of the previous condition
        else:
            # execute this function and send "Enter 1 to add drink, 2 to replenish drink and 0 to exit." to the function
            error_Prompt("Enter 1 to add drink, 2 to replenish drink and 0 to exit.",1)


#vendor add drink section
def add_drink():
    addStatus = False
     # A while loop that will be executed until "addStatus" equals to True
    while addStatus != True:

        # user_Input "(drink_id)"  to ask users enter the drink ID.
        drink_id = input("Enter Drink Id: ")

        # A if condition to check if drink_id, converted to uppercase is in the "items dictionary" (a dictionary that contains the drinks)
        if drink_id.upper() in items:

            # if the condition met, execute error_Prompt and send "Drink id exist!" to erro_Prompt
            error_Prompt("Drink id exist!",0)


            #  addStatus = False thus repeating the loop
            addStatus = False


        # condition to prevent user from using 0 as a drink id/ to prevent conflict with the exit function
        #Reasoning for not combining togeather with "if drink_id.upper() in items:" is to have the ability to let user which and where went wrong.
        # A if condition to check if drink_id equals to "0"
        elif drink_id == '0':

            # if the condition met,  "Cannot use 0 as a drink ID"
            error_Prompt("Cannot use 0 as a drink ID",1)

            #  addStatus = False thus repeating the loop
            addStatus = False


        # else condition if User_Input, did not meet any of the previous condition
        else:

            # user_Input "(description)"  to ask users enter the drink description.
            description = input("Enter description of drink: ")
            addStatus = True



            #loop to check if the user input for price is correct (integer or decimal and vaildate that amount is not negative)
            price_Status = False

            # A while loop that will be executed until "price_Status" equals to True
            while price_Status != True:

                # A user_Input "(price)"  to ask users "Enter Price: $".
                price = input("Enter Price: $")

                 # A if condition validate if replace the "." to " " from price, equals to digit and to see validate the amount of "." and to validate if the price is more than 0
                if ((price.replace(".","")).isdigit() and (price.count('.')<2) and float(price)>0):

                    # addStatus = True thus ending the loop
                    addStatus = True

                    #Second loop to validate if quantity is an integer, no decimal allowed
                    quantity_Status = False

                    # A while loop that will be executed until "quantity_Status" equals to True
                    while quantity_Status != True:

                        # A user_Input "(quantity)"  to ask users "Enter quantity:  ".
                        quantity = input("Enter quantity: ")

                        # A if condition to vaildate if quantity is a digit
                        if quantity.isdigit():

                            # quantity_Status = True thus ending the loop
                            quantity_Status = True

                            # return the drink_id,description,price in float,quantity in integer
                            return drink_id,description,float(price),int(quantity)

                        # A else condition if user_Input "(quantity)" did not met the previous condition
                        else:

                            # execute this function and send 'Please enter Numeric values, no decimal.' to the function
                            error_Prompt("Please enter Numeric values, no decimal.",1)

                              #  price_Status = False thus repeating the loop
                            quantity_Status = False

                # A else condition if user_Input "(price)" did not met the previous condition
                else:
                    # execute this function and send 'lease enter numeric values, or decimal values'.
                    error_Prompt("Please enter numeric values, or decimal values.",1)

                    #  price_Status = False thus repeating the loop
                    price_Status = False

# add the drinks into the dictionary
# function activitate with the arguments (drink_id, description, price, quantity) recieved
def add_drink_type(drink_id, description, price, quantity):

    # insert the arguments (drink_id, description, price, quantity) into the list
    items[drink_id]={'description': description, 'price': price, 'quantity': quantity}
    #return '{}. {} (${})  Qty : {}'.format(drink_id, items[drink_id]['description'], items[drink_id]['price'], items[drink_id]['quantity'])

#appending the quantity
def append_Quantity():

    # execute this function and send 'items'/(dicitonary  to the printItems() function.
     printItems(items)

     status = False

     # A while loop that will be executed until "status" equals to True
     while status != True:

         #converting the "drink id" variable of the user input to uppercase
         drink_Id = input("Enter Drink id: ").upper()

        # validating if the drink is in the dictionary
        # A if condition to validate if drink_Id/(user input) is in items (dictionary)
         if drink_Id in items:

             # a get function to grab drinks_ID/User Input that is present in the items/(dictionary)
             items.get(drink_Id)

             #validating if the drink quantity is more than 5
             if (int(items.get(drink_Id)['quantity'])) > 5:

                 # a print statement that prints "No need to replenish. Quantity is greater than 5. ", if the condition is met.
                 print("No need to replenish. Quantity is greater than 5. ")

                 # set status to true thus ending the loop
                 status = True

             # A else condition if the User input("drink id") did not met the if conditions.
             else:

                 # declearing topUp_Status to be False.
                 topUp_Status = False

                 # a while loop that will execute till topUp_Status equals to True.
                 while topUp_Status != True:

                     #a input called topup that collects users input.
                     topup = input("Enter quantity: ")

                     # checck if the top up input is a digit or not, not counting in decimal.
                     # a if condition that validates the user input/(topup) is a digit.
                     if topup.isdigit():

                         #if condition is met, proceed to the items/(dictionary) to get drink_id user input get the quantity and update the quantity with the top up values
                         items.get(drink_Id)['quantity'] = int(items.get(drink_Id)['quantity'])+int(topup)

                         # a print statement that prints the "description has been topup" using .format method
                         print("{} has been topup!".format(items.get(drink_Id)['description']))

                         # change the topUp_Status = True thus ending the loop
                         topUp_Status = True

                         #change the topUp_Status = True thus ending the loop
                         status = True

                     # a else condition if the topup is not digit.
                     else:

                         # execute the function and send "Enter Numeric values." to the error_Prompt function
                         error_Prompt("Enter Numeric values.",1)

                         # change the topUp_Status = False thus repeating the loop
                         topUp_Status = False

         #A else condition that execute if drink_Id/(user input) is not in items(dictionary)
         else:

            # execute the function and send "No drink with this drink id. Try again." to the error_Prompt function
            error_Prompt("No drink with this drink id. Try again.",0)

            # Set the status to False thus repeating the loop
            status = False

#Finding the max Length of items in the dictionary.
def maxLength(dictionary):

    #Variable that declares max length = 0
    maxLength = 0

   # a for loop that executes 2 items in dictionary(item) items and loops evey items in dictionary(items).
    for drinks_ID, Drinks_info in dictionary.items():

        # a variable that sums up the length of the 'description' length in items(dictionary) , length of the drinks_ID length in items(dictionary) and the length of 'price' length in items(dictionary).
        length = (int(len(Drinks_info['description']))+int(len(drinks_ID))+int(len(str(Drinks_info['price']))))

        # a if condition to validate if the length is bigger than the max length
        if length > maxLength:

            # if condition is met, max length equals to the length
            maxLength = length

    #return the maxlength to whoever called this function
    return maxLength

#printing every items in the dictionary
def printItems(dictionary):

    # a variable that is called max, execute maxLength() function and send "dictionary"
    max = maxLength(dictionary)

    # a for loop that executes 2 items in dictionary(item) items and loops evey items in dictionary(items).
    for drinks_ID, Drinks_info in dictionary.items():

        # a if condition to validate if (the length of Drinks_info['description'] + length of drinks_ID + length of 'price' -1) is lesser than the max.
        if((int(len(Drinks_info['description']))+int(len(drinks_ID))+int(len(str(Drinks_info['price']))))-1 < max):

            #a variable incrementa equals to max - (length of 'description' + length of drinks_ID + length Drinks_info['price'])
            incremental = max - ((int(len(Drinks_info['description']))+int(len(drinks_ID))+int(len(str(Drinks_info['price'])))))

            # converting 0 to ***out of stock***

            # a if condition to validate if Drinks_info['quantity'] equals to zero
            if(Drinks_info['quantity'] == 0):

                # print ***out of stock*** if the if condition is met and use the incremental to multiply the " " to create the needed spaces to format the qty to be on the right
                print("{}. {} (${}) {}***out of stock***".format(drinks_ID, Drinks_info['description'], Drinks_info['price'],(incremental*" ")))

            # a else condition if Drinks_info['quantity'] did not meet the previous condition
            else:

                # print the ID, description of the drinks the price of the drinks, use the incremental to multiply the " " to create the needed spaces to format the qty to be on the right and print the quantity of drinks.
                print("{}. {} (${}){} Qty : {}".format(drinks_ID, Drinks_info['description'], Drinks_info['price'],(incremental*" "),Drinks_info['quantity']))

#customer part
def customer():
    #seperate dictionary to store selected drinks
    # A variable called append_items, the append_items uses the copy function that is imported. the deepcopy actually duplicate the items,
    # if you just use append_items = items the append items will just refer to it and any changes made to the append_items, the items will also be effected.
    appeded_items = copy.deepcopy(items)

    # Declearing a variable called drinks_counter and make it equals to 0
    drinks_counter = 0

    # Declearing a variable called cost and make it equals to 0
    cost = 0

    # Execute the messages function
    messages()

    # Execute the printItems function and send the appeded_items to the function
    printItems(appeded_items)

    # A print statement to print '0. Exit / Payment'
    print('0. Exit / Payment')

    #a while loop that will execute till break
    while True:

        # a variable called "drink_Id" and request a user input to "Enter Choice: "" and convert them to uppercase
        drink_Id = input("Enter Choice: ").upper()

        #validate if drink is in the items dictionary.
        # a if condition to check if user input(drink_Id) is in appended_items(a duplicate of the items/(dictionary).
        if drink_Id in appeded_items:

            # a if condition to check appeded_items.get(drink_Id)['quantity'] is more  than zero,  a if condition to check ['quantity'] in appended items is more than zero
            if int(appeded_items.get(drink_Id)['quantity']) > 0:

                # change the 'quantity' in the "appended items"/dictionary by converting the items to interger and minus it by 1
                appeded_items.get(drink_Id)['quantity'] = (int(appeded_items.get(drink_Id)['quantity'])-1)

                # a variable "drinks_counter" incremental by 1
                drinks_counter = drinks_counter + 1

                # a variable "cost" equals to cost + 'price' of the items that is selected by the drink id converted to float.
                cost = cost + float(appeded_items.get(drink_Id)['price'])

                # a print statement to print the amount of drinks selected
                print("No. of drinks selected = {}".format(drinks_counter))

            # a else condition if appeded_items.get(drink_Id)['quantity']) less than zero
            else:
                  # a print statement to print the the drink description is out of stock
                print("{} is out of stock".format(appeded_items.get(drink_Id)['description']))

        # a elif condition to check if user input(drink_Id) is equal to zero.
        elif drink_Id == "0":

            # A return statement to return the drink_Id,appeded_items,cost,drinks_counter to the parts that execute customer(): function.
            return(drink_Id,appeded_items,cost,drinks_counter)

            #break the loop
            break

        # a else condition to be executed if the drink_Id did not met the if and elif condition.
        else:
            #execute this function,and send "invalid Option. Enter Valid Drink ID's or 0 to exit/payment"
           error_Prompt("invalid Option. Enter Valid Drink ID's or 0 to exit/payment",0)



#check if user enter a integer for the notes that is more or equal to 0. No decimal allowed.
def validator(quantity,dorra,amountLeft):

    # a if condition to validate if quantity is digit.
    if quantity.isdigit():

        # A variable "sum" execute a function "calculator" and send quantity,dorra,amountLeft to the "calculator" function
        sum = calculator(quantity,dorra,amountLeft)

        # return True and return sum
        return True, sum

    # a else condition if the "quantity" did not meet the previous if condition.
    else:

        #a function "error_prompt" and send "Enter integer that is more or eqaul to 0, no decimal allowed." to the error_Prompt function that will be execute if the else condition is met,
        error_Prompt("Enter integer that is more or equals to 0, no decimal allowed.",1)

        #Return False and zero as a place holder.
        return False,0

#ask users for the notes
def loop(dorra,cal):

     # a while loop that will execute till break
     while True:

         # a variable called "dorra" that ask user to input the amount of notes.
         Dorra = input("Enter no. of ${} notes: ".format(dorra))

         #a variable that executes the function "Validator" and sends "Dorra,dorra,cal" to the validator function.
         valid = validator(Dorra,dorra,cal)

         # a  if condiction that validates the "valid" item using slicing method to validate if the item is true.
         if valid[0]==True:

             # return the "item" using slicing method if the if condition is met.
             return valid[1]

             #break the loop
             break


#calculate the Notes:
def calculator(quantity,dorra,amountleft):

    # a variable "amount" that uses quantity convertrd to int to multiply with the dorra converted to float.
    amount = int(quantity)*float(dorra)

    # a variable "amountleft" that uses amout converted to float - amountleft converted to float.
    amountleft = float(amount) - float(amountleft)

    # return the amountleft to the place that executed the calculator function.
    return amountleft


#final message to end the customer loop.
def finalCustomerMessage(amountLeft,appendedItems):

    # a print statement to print "Please collect your change: ${:.2f}"
    print("Please collect your change: ${:.2f}".format(amountLeft)+"\n"+"Drinks Paid. Thank you.")

    # update the original items(dictionary) containing the drinks to the appended dictionary.
    # a variable "items" copying the appendedItems dictionary using the deepCopy function from Import copy
    items = copy.deepcopy(appendedItems)

    #test to see if the purchaced items is updated.
    #print(items)

#note loop.
def cash_Management(append_items,cost,drinks_counter,items):
    #condition for user who enter the customer part, but did not buy any drinks.

   # a if condition to check if the drink conunter equals to 0
    if drinks_counter == 0:

        # a print statement to print "Thank you for using ABC Vending Machine." if it met the if condition.
        print("Thank you for using ABC Vending Machine.")

    # a else condition if drinks_counter did not met the previous if statement.
    else:
       #conditon for user who enter the customer part and did purchace at least 1 drink.

       # a variable "status1" that is declared as false.
       status1 = False

       # a loop to loop thru the commands
       # a while loop that will execute till status1 till status1 equals to true.
       while status1 != True:

            # a print statement that prints "Please pay: ${:.2f}\nIndicate your payment:"
            print("Please pay: ${:.2f}\nIndicate your payment:".format(cost))

            # a variable "amountLeft" execute a "loop" function and sends "10,cost" to the "loop" function, to the place that execute the "loop" function.
            amountLeft = loop(10,cost)

            # a variable "status1" equals True thus ending the loop
            status1 = True

            #will ask for driffrent notes if amountleft is < 0
            # a if condition to validate if amountLeft is less than 0
            if amountLeft < 0:

                # a variable "amountLeft" that executes the "loop" function and sends "5,-1*amountLeft" to the loop function, to the place that execute the "loop" function.
                amountLeft = loop(5,-1*amountLeft)

                #will ask for driffrent notes if amountleft is < 0
                # a if condition that validate if amountleft is less than 0
                if amountLeft <0:

                    # a variable "amountLeft" that executes the "loop" function and sends "2,-1*amountLeft" to the loop function, to the place that execute the "loop" function.
                    amountLeft = loop(2,-1*amountLeft)

                    # a if condition to validate if amount is lesser than 0
                    if amountLeft <0:

                        #ask user if they want to cancel the purchace.
                        # a variable "status" declared to be False
                        status2 = False

                        # a print statement that will  print "Not enough to pay for the drinks\nTake back your cash!  " if it met the previous if condition
                        print("Not enough to pay for the drinks\nTake back your cash!  ")

                        #a loop to validate user reply if it is Yes or no.
                        # a while loop that will execute till status2 equals to True
                        while status2 != True:

                            # a variable "Cancel" that will ask for user input ("Do you want to cancel your order Y/N: ")
                            cancel = input("Do you want to cancel your order Y/N: ")

                            # a if condition to validate if "cancel" converted to uppercase equals to "Y"
                            if cancel.upper() == "Y":

                                # a print statement to print "Purchace has been cancled." if the previous "if condition" is met
                                print("Purchase is cancelled. Thank you.")

                                # a variable "status2" equals to True
                                status2 = True

                                # a print statement to print "items"
                                # print(items)

                            # a elif condition to validate if "cancel" converted to uppercase equals to "N"
                            elif cancel.upper() == "N":

                                # a variable "status2" equals to True thus ending this loop
                                status2 = True

                                # a variable "status1" equals to False thus repeating the previous loop.
                                status1 = False

                            # a else condition if the cancel did not meet the if or elif condition.
                            else:

                                #execute "error_Prompt" function and send 'Enter "Y" for yes and "N" for no.' to the "error_Prompt" function
                                error_Prompt('Enter "Y" for yes and "N" for no.',1)

                    # a else condition if amountLeft is more than 0
                    else:

                        # execute "finalCustomerMessage" function and send "amountLeft,append_items" to "finalCustomerMessage" function.
                        finalCustomerMessage(amountLeft,append_items)

                # a else condition if amountLeft is more than 0
                else:

                    # execute "finalCustomerMessage" function and send "amountLeft,append_items" to "finalCustomerMessage" function.
                    finalCustomerMessage(amountLeft,append_items)

            # a else condition if amountLeft is more than 0
            else:

                 # execute "finalCustomerMessage" function and send "amountLeft,append_items" to "finalCustomerMessage" function.
                finalCustomerMessage(amountLeft,append_items)


#execution of the vending machine


#a variable "main_loop" equals to False.
main_loop = False

# a while loop executed till the main_loop equals to True
while main_loop != True:
    # a variable "greeting" that execute the greeting function.
    greeting = greetings()

    # a if condition to validate if "greeting" converted to uppercase equals to "Y".
    if(greeting.upper())=="Y":
        #exeucte the "messages" function.
        messages()

        #execute the "vendorMsg" function.
        vendorMsg()

        # A while loop that execute till it breaks
        while True:
            # a variable "vendor_reply" executes the function "vendor".
            vendor_reply = vendor()

            # a if condition to validate if "vendor_reply" equals to 1.
            if(vendor_reply == "1"):
                # a variable "drinks" executes the function "add_drink()".
                drinks = add_drink()

                # execute "add_drink_type" function and send "drinks[0]).upper(),drinks[1],drinks[2],drinks[3]" to "add_drink_type" function.
                add_drink_type((drinks[0]).upper(),drinks[1],drinks[2],drinks[3])

                # declaring main_loop = False thus repeating the main loop.
                main_loop = False

            # a elif condition to validate if "vendor_reply" equals to 2.
            elif(vendor_reply == "2"):

                #execute the "append_Quantity" function.
                append_Quantity()

                # declaring main_loop = False thus  repeating the main loop.
                main_loop = False

            # a else condition to be execute if "vendor_reply" did not meet the previous if or elif condition.
            else:

                # a break statement to end this loop
                break

                #declaring main_loop = False thus repeating the main loop.
                main_loop = False

        # a else condition to be execute if "greeting" did not meet the if condition.
    else:
        # a variable "customerReply" execute the "customer" function
        custpmerReply = customer()

        # A if condition to validate if "custpmerReply[0]" equals to 0
        if custpmerReply[0]=="0":
            #execute "cash_Management" function and sends "custpmerReply[1],custpmerReply[2],custpmerReply[3],items" to the "cash_Management" function
            cash_Management(custpmerReply[1],custpmerReply[2],custpmerReply[3],items)

            #declaring main_loop = True thus ending the main loop.
            main_loop = True






