#Author: Ang yu jie
#Admin No: 214144U
drinks = {'IM': {'description': 'Iced Milo', 'price': 1.50},
         'HM': {'description': 'Hot Milo', 'price': 1.20},
         'IC': {'description': 'Ice Coffee', 'price': 1.50},
         'HC': {'description': 'Hot Coffee', 'price': 1.20},
         '1P': {'description': '100 Plus', 'price': 1.10},
         'CC': {'description': 'Coca Cola', 'price': 1.30}
         }


def error_Prompt(errorCode):
    print("Invalid Input,",errorCode)

#check if user enter a integer for the notes that is more or equal to 0. No decimal allowed.
def validator(quantity,dorra,amountLeft):
    if quantity.isdigit():
        sum = calculator(quantity,dorra,amountLeft)
        return True, sum
    else:
        error_Prompt("Enter integer that is more or eqaul to 0, no decimal allowed.")
        return False,0

#ask users for the notes
def loop(dorra,cal):
     status2 = False
     while status2 != True:
         Dorra = input("Enter no. of ${} notes:  ".format(dorra))
         valid = validator(Dorra,dorra,cal)
         if valid[0]==True:
             return valid[1]
             status2 = True
         else:
             status2 =False


#calculate the Notes:
def calculator(quantity,dorra,amountleft):
    amount = float(quantity)*float(dorra)
    amountleft = float(amount) - float(amountleft)
    return amountleft

#final message to end the customer loop.
def finalCustomerMessage(amountLeft,appendedItems):
    print("Please collect your change: ${:.2f}".format(amountLeft)+"\n"+"Drinks Paid. Thank you.")



#final message to end the customer loop.
def finalCustomerMessage(amountLeft):
    print("Please collect your change: ${:.2f}".format(amountLeft)+"\n"+"Drinks Paid. Thank you.")
    # change the quantity of the drinks if customer purchaced the drink.


error = "Invalid Input"
FirstPart = False
while FirstPart != True:
    Greeting="Welcome to ABC Vending Machine.\nSelect from the following choices to continue:"
    question = input("Are you a vendor (Y/N) ? ")
    question2 = "Enter Choice: "

    if question.upper() == 'Y':
        print(Greeting)
        print("1. Add Drink Type\n2. Replenish Drink\n0. Exit")
        vendorStatus = False
        while vendorStatus != True:
            vendorReply = input("Enter Choice: ")
            if vendorReply == "0":
                vendorStatus = True
                FirstPart = False
            else:
                error_Prompt("currently vendor option is unavailable in part 1 please enter 0 to exit the loop. ")
                vendorStatus = False

    elif(question.upper() == "N"):
        drinks_counter = 0
        subtotal = 0
        FirstPart = True
        print(Greeting)
        for drinks_ID, Drinks_info in drinks.items():
            print("{}. {} (${})".format(drinks_ID, Drinks_info['description'], Drinks_info['price']))
        print('0.Exit / Payment')
        customer_selectionloop = False
        while customer_selectionloop != True:
            customer_Drink_input = input("Enter Choice: ")
            if customer_Drink_input.upper() in drinks:
                drinks_counter = drinks_counter + 1
                subtotal = subtotal + float(drinks.get(customer_Drink_input.upper())['price'])
                print("No. of drinks selected =",drinks_counter)

            elif(customer_Drink_input =='0'):
                customer_selectionloop = True
                if(drinks_counter == 0):
                    print("Thankyou")

                else:
                     print("Please pay: ${:.2f}".format(subtotal))
                     status1 = False
                     # a loop to loop thru the commands
                     while status1 != True:
                         amountLeft = loop(10,subtotal)
                         status1 = True
                         #will ask for driffrent notes if amountleft is < 0
                         if amountLeft < 0:
                             amountLeft = loop(5,-1*amountLeft)
                             #will ask for driffrent notes if amountleft is < 0
                             if amountLeft <0:
                                 amountLeft = loop(2,-1*amountLeft)
                                 if amountLeft <0:

                                     #ask user if they want to cancel the purchace.
                                     status2 = False
                                     print("Not enough to pay for the drinks\nTake Back your Cash!  ")
                                      #a loop to validate user reply if it is Yes or no.
                                     while status2 != True:
                                          cancel = input("Do you want to cancel your order Y/N: ")
                                          if cancel.upper() == "Y":
                                              print("Purchace has been cancled.")
                                              status2 = True
                                          elif cancel.upper() == "N":
                                             status2 = True
                                             status1 = False
                                          else:
                                             error_Prompt('Enter "Y" for yes and "N" for no.')
                                             status4 = False
                                 else:
                                     finalCustomerMessage(amountLeft)

                             else:
                                 finalCustomerMessage(amountLeft)

                         else:
                             finalCustomerMessage(amountLeft)



